
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/syscall.h>

#define __NR_set_array 456
#define __NR_get_array 457

static void usage(const char* prog)
{
    fprintf(stderr,
        "Usage:\n"
        "  %s set_array <index> <value>   # index:[0..63], value: 32-bit int\n"
        "  %s get_array <index>\n", prog, prog);
}

int main(int argc, char* argv[])
{
    if (argc < 3) {
        usage(argv[0]);
        return 1;
    }

    if (strcmp(argv[1], "set_array") == 0) {
        if (argc != 4) {
            usage(argv[0]);
            return 1;
        }
        long idx = strtol(argv[2], NULL, 0);
        long val = strtol(argv[3], NULL, 0);

        long ret = syscall(__NR_set_array, (int)idx, (int)val);
        if (ret == -1) {
            fprintf(stderr, "set_array failed (idx out of range?)\n");
            return 1;
        }
        printf("OK: array[%ld] = %ld\n", idx, val);
        return 0;

    } else if (strcmp(argv[1], "get_array") == 0) {
        if (argc != 3) {
            usage(argv[0]);
            return 1;
        }
        long idx = strtol(argv[2], NULL, 0);

        long ret = syscall(__NR_get_array, (int)idx);
        if (ret == -1) {
            fprintf(stderr, "get_array failed (idx out of range?)\n");
            return 1;
        }
        printf("array[%ld] = %ld\n", idx, ret);
        return 0;

    } else {
        usage(argv[0]);
        return 1;
    }
}

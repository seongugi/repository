
#include <linux/kernel.h>
#include <linux/syscalls.h>
#include <linux/types.h>

#define ARRAY_BYTES   256
#define ELEM_BYTES    4
#define ARRAY_LEN     (ARRAY_BYTES / ELEM_BYTES)

static int array_store[ARRAY_LEN];

SYSCALL_DEFINE2(set_array, int, index, int, value)
{
    if (index < 0 || index >= ARRAY_LEN)
        return -1;

    array_store[index] = value;
    return 0;
}

SYSCALL_DEFINE1(get_array, int, index)
{
    if (index < 0 || index >= ARRAY_LEN)
        return -1;

    return array_store[index];
}
